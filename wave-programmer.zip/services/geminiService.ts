
import { GoogleGenAI } from "@google/genai";

const getApiKey = (): string => {
  try {
    // In a browser environment without a build step, `process` is not defined.
    // This check safely accesses the environment variable if it exists.
    if (typeof process !== 'undefined' && process.env && process.env.API_KEY) {
      return process.env.API_KEY;
    }
  } catch (e) {
    console.error("Error accessing process.env.API_KEY. AI features may not work.", e);
  }
  return "";
};

const apiKey = getApiKey();
const isApiKeyAvailable = !!apiKey;

if (!isApiKeyAvailable) {
    console.warn("API_KEY environment variable not set or accessible. AI features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: apiKey || "" });

export const summarizeContent = async (content: string): Promise<string> => {
    if (!isApiKeyAvailable) {
        throw new Error("Gemini API key is not configured.");
    }

    const prompt = `Please summarize the following tech article in three concise bullet points, focusing on the key takeaways. Format the output as a list.
    
    Article:
    ---
    ${content}
    ---
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                temperature: 0.3,
            }
        });
        return response.text;
    } catch (error) {
        console.error("Error summarizing content with Gemini API:", error);
        throw new Error("Failed to generate summary. Please check the console for details.");
    }
};

export { isApiKeyAvailable };
