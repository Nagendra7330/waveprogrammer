
import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';
import type { User } from '../types.ts';

// Mock users database
const mockUsers: User[] = [
  { id: 'user-1', name: 'John Doe', email: 'john@example.com', avatarUrl: 'https://i.pravatar.cc/150?u=john-auth' },
  { id: 'user-admin', name: 'Admin', email: 'admin@waveprogrammer.com', avatarUrl: 'https://i.pravatar.cc/150?u=admin', isAdmin: true },
];

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string) => boolean;
  logout: () => void;
  signup: (name: string, email: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    try {
      const storedUser = sessionStorage.getItem('authUser');
      if (storedUser) {
        setUser(JSON.parse(storedUser));
      }
    } catch (e) {
      console.error("Could not parse user from session storage", e);
      sessionStorage.removeItem('authUser');
    } finally {
      setLoading(false);
    }
  }, []);

  const login = (email: string): boolean => {
    const foundUser = mockUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (foundUser) {
      setUser(foundUser);
      sessionStorage.setItem('authUser', JSON.stringify(foundUser));
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    sessionStorage.removeItem('authUser');
  };

  const signup = (name: string, email: string): boolean => {
    if (mockUsers.some(u => u.email.toLowerCase() === email.toLowerCase())) {
      return false; // User already exists
    }
    const newUser: User = {
      id: `user-${Date.now()}`,
      name,
      email,
      avatarUrl: `https://i.pravatar.cc/150?u=${email}`,
    };
    mockUsers.push(newUser);
    setUser(newUser);
    sessionStorage.setItem('authUser', JSON.stringify(newUser));
    return true;
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, signup }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};