export interface Author {
  name: string;
  avatarUrl: string;
}

export interface User extends Author {
  id: string;
  email: string;
  isAdmin?: boolean;
}

export interface Comment {
  id: string;
  user: User;
  content: string;
  date: string; // ISO 8601
}

export interface Post {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  imageUrl: string;
  author: Author;
  date: string; // ISO 8601 format string
  tags: string[];
  comments: Comment[];
}