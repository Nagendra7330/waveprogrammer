


import React, { useState, useEffect, useCallback } from 'react';
import type { Post, Comment, User } from '../types.ts';
import { useNavigate } from 'react-router-dom';

// Mock users for comments
const mockUser1: User = { id: 'user-1', name: 'Commenter One', email: 'one@example.com', avatarUrl: 'https://i.pravatar.cc/150?u=commenter-one' };
const mockUser2: User = { id: 'user-2', name: 'Commenter Two', email: 'two@example.com', avatarUrl: 'https://i.pravatar.cc/150?u=commenter-two' };

const defaultPosts: Post[] = [
  {
    id: 'mastering-react-hooks',
    title: 'Mastering React Hooks: A Deep Dive into State and Effects',
    excerpt: 'Unlock the full potential of functional components in React. This guide explores useState, useEffect, and custom hooks with practical examples.',
    content: `
React Hooks have revolutionized how we write components. They allow us to use state and other React features without writing a class. This article is a deep dive into the most essential hooks.

**useState: The Foundation of State**
The \`useState\` hook is the most basic building block. It lets you add React state to function components.
\`\`\`javascript
const [count, setCount] = useState(0);
\`\`\`
Here, \`count\` is our state variable, and \`setCount\` is the function to update it. It's simple, yet powerful.

**useEffect: Handling Side Effects**
Side effects are operations that affect other components and can't be done during rendering. This includes data fetching, subscriptions, or manually changing the DOM. \`useEffect\` is the solution.

For fetching data, you might write something like this:
\`\`\`javascript
useEffect(() => {
  fetch('https://api.example.com/data')
    .then(res => res.json())
    .then(setData);
}, []); // The empty array means this effect runs once on mount
\`\`\`
The dependency array is key to controlling when your effect re-runs. An empty array means it runs once, similar to \`componentDidMount\`.

**Building Custom Hooks**
The true power of Hooks is unlocked when you start building your own. A custom hook is a JavaScript function whose name starts with "use" and that may call other Hooks.

For example, a hook to track window size:
\`\`\`javascript
function useWindowSize() {
  const [size, setSize] = useState([window.innerWidth, window.innerHeight]);
  useEffect(() => {
    const handleResize = () => setSize([window.innerWidth, window.innerHeight]);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  return size;
}
\`\`\`
This encapsulates complex logic into a simple, reusable function. By understanding and combining these hooks, you can write cleaner, more declarative, and highly reusable React code.
    `,
    imageUrl: 'https://picsum.photos/seed/react/1200/600',
    author: { name: 'Jane Doe', avatarUrl: 'https://i.pravatar.cc/150?u=jane' },
    date: '2024-07-20T10:00:00Z',
    tags: ['React', 'JavaScript', 'Web Development'],
    comments: [
      { id: 'c1-1', user: mockUser1, content: 'Great deep dive into hooks! This really cleared some things up for me.', date: '2024-07-21T11:00:00Z' },
      { id: 'c1-2', user: mockUser2, content: 'Thanks for the custom hook example. Very practical.', date: '2024-07-21T12:30:00Z' },
    ]
  },
  {
    id: 'deploying-on-vercel',
    title: 'From Localhost to Live: Deploying Your App on Vercel',
    excerpt: 'Deploying your web application has never been easier. Learn how to take your project from your local machine to a live URL with Vercel in minutes.',
    content: `
Vercel has streamlined the deployment process for frontend developers. It offers a seamless experience, especially for projects built with frameworks like Next.js, React, and Vue.

**Step 1: Push to Git**
Vercel's workflow is built around Git. The first step is to have your project on a Git provider like GitHub, GitLab, or Bitbucket.
\`\`\`bash
git init
git add .
git commit -m "Initial commit"
# Push to your GitHub repository
\`\`\`

**Step 2: Import Project on Vercel**
Once your project is on GitHub, log in to your Vercel account and click "Add New... > Project". You can import your Git repository directly. Vercel automatically detects the framework (e.g., Create React App) and configures the build settings.

**Step 3: Deploy!**
With the project imported, all you have to do is click "Deploy". Vercel will handle the rest: installing dependencies, building the project, and deploying it to its global CDN.

**Continuous Deployment**
The real magic is in continuous deployment. Every time you push a new commit to your main branch, Vercel automatically re-deploys your application. Pushing to other branches creates unique preview deployments, which are perfect for testing changes before they go to production. This Git-based workflow is a game-changer for team collaboration and release cycles.
    `,
    imageUrl: 'https://picsum.photos/seed/vercel/1200/600',
    author: { name: 'John Smith', avatarUrl: 'https://i.pravatar.cc/150?u=john' },
    date: '2024-07-18T14:30:00Z',
    tags: ['Deployment', 'Vercel', 'DevOps'],
    comments: [],
  },
  {
    id: 'gemini-api-intro',
    title: 'Getting Started with the Gemini API for AI-Powered Features',
    excerpt: 'Integrate powerful AI capabilities into your applications with Google\'s Gemini API. This post covers the basics of setting it up and making your first API call.',
    content: `
The Gemini API provides access to Google's state-of-the-art large language models. It's surprisingly easy to integrate into your projects to build AI-powered features like text generation, summarization, and more.

**Setting Up Your Project**
First, you'll need an API key from the Google AI Studio. Store this key securely as an environment variable. Then, install the official SDK:
\`\`\`bash
npm install @google/genai
\`\`\`

**Making Your First API Call**
The SDK simplifies interaction with the model. Here's a basic example of generating text from a prompt:

\`\`\`javascript
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

async function run() {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: 'Write a short story about a programmer who discovers a friendly bug.',
  });
  console.log(response.text);
}

run();
\`\`\`

**Possibilities are Endless**
From here, you can explore more advanced features like streaming responses for real-time applications, providing images as input for multi-modal tasks, or defining a JSON schema for structured output. The Gemini API is a powerful tool for any developer looking to add a touch of intelligence to their apps.
    `,
    imageUrl: 'https://picsum.photos/seed/gemini/1200/600',
    author: { name: 'Alex Johnson', avatarUrl: 'https://i.pravatar.cc/150?u=alex' },
    date: '2024-07-15T09:00:00Z',
    tags: ['AI', 'Gemini API', 'Node.js'],
    comments: [],
  },
   {
    id: 'tailwind-for-design',
    title: 'Why Tailwind CSS is a Game-Changer for Rapid UI Development',
    excerpt: 'Move faster from idea to implementation with Tailwind CSS. We explore how this utility-first framework accelerates development without sacrificing design quality.',
    content: `
Tailwind CSS has taken the frontend world by storm, offering a different approach to styling web applications. Instead of writing custom CSS classes, you build designs directly in your HTML using utility classes.

**The Utility-First Approach**
Consider styling a button. Traditionally, you might write:
\`\`\`css
.btn-primary {
  background-color: #3490dc;
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 0.25rem;
}
\`\`\`
With Tailwind, you'd do this in your markup:
\`\`\`html
<button class="bg-blue-500 text-white font-bold py-2 px-4 rounded">
  Click me
</button>
\`\`\`
This might seem verbose at first, but it has huge benefits. You're not constantly switching between HTML and CSS files, and you're not inventing class names.

**Consistency and Constraints**
Tailwind provides a well-thought-out design system out of the box. Spacing, colors, and typography are all based on a consistent scale. This prevents "magic numbers" and helps maintain visual harmony across the application, even with multiple developers.

**Customization and Performance**
Tailwind is highly customizable. You can configure everything from your color palette to spacing units in the \`tailwind.config.js\` file. When it's time to build for production, Tailwind uses PurgeCSS to scan your files and remove any unused utility classes, resulting in a tiny, highly optimized CSS file. This combination of developer experience and performance makes Tailwind a powerful choice for modern web development.
    `,
    imageUrl: 'https://picsum.photos/seed/tailwind/1200/600',
    author: { name: 'Jane Doe', avatarUrl: 'https://i.pravatar.cc/150?u=jane' },
    date: '2024-07-12T11:45:00Z',
    tags: ['CSS', 'TailwindCSS', 'UI/UX'],
    comments: [],
  },
];


// --- START OF HMR-RESILIENT STATE MANAGEMENT ---

interface BlogDataStore {
  posts: Post[];
  listeners: Record<symbol, React.Dispatch<React.SetStateAction<Post[]>>>;
}

// Attach the store to the window object to make it resilient to Hot Module Replacement (HMR).
// This ensures that the data and listeners are not lost when the file is saved during development.
if (!(window as any).__blog_data_store__) {
  const initialPosts: Post[] = JSON.parse(localStorage.getItem('blogPosts') || 'null') || defaultPosts;
  (window as any).__blog_data_store__ = {
    posts: initialPosts,
    listeners: {},
  };
}

const store: BlogDataStore = (window as any).__blog_data_store__;

const syncStorage = (posts: Post[]) => {
  localStorage.setItem('blogPosts', JSON.stringify(posts));
};

function broadcast(newPosts: Post[]) {
  store.posts = newPosts;
  syncStorage(store.posts);
  Object.values(store.listeners).forEach(listener => listener(store.posts));
}

// --- END OF HMR-RESILIENT STATE MANAGEMENT ---

export const useBlogData = () => {
  const [posts, setPosts] = useState<Post[]>(store.posts);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  
  const [listenerId] = useState(() => Symbol('listenerId'));

  useEffect(() => {
    store.listeners[listenerId] = setPosts;
    setPosts(store.posts); // Ensure up-to-date on mount

    const timer = setTimeout(() => setLoading(false), 200);

    return () => {
      delete store.listeners[listenerId];
      clearTimeout(timer);
    };
  }, [listenerId]);

  const getPostById = useCallback((id: string): Post | undefined => {
    return store.posts.find(post => post.id === id);
  }, []);

  const addComment = useCallback((postId: string, comment: { user: User; content:string}) => {
     const newPosts = store.posts.map(p => {
        if (p.id === postId) {
          const newComment: Comment = {
            id: `c-${Date.now()}`,
            user: comment.user,
            content: comment.content,
            date: new Date().toISOString()
          };
          return { ...p, comments: [...p.comments, newComment] };
        }
        return p;
      });
      broadcast(newPosts);
  }, []);

  const deleteComment = useCallback((postId: string, commentId: string) => {
    const newPosts = store.posts.map(p => {
        if (p.id === postId) {
          const updatedComments = p.comments.filter(c => c.id !== commentId);
          return { ...p, comments: updatedComments };
        }
        return p;
      });
    broadcast(newPosts);
  }, []);

  const createPost = useCallback((post: Omit<Post, 'id' | 'date' | 'comments' | 'author'>, author: User) => {
    const newPost: Post = {
      ...post,
      id: post.title.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '') + `-${Date.now()}`,
      date: new Date().toISOString(),
      comments: [],
      author: { name: author.name, avatarUrl: author.avatarUrl }
    };
    const newPosts = [newPost, ...store.posts];
    broadcast(newPosts);
    navigate(`/post/${newPost.id}`);
  }, [navigate]);

  const updatePost = useCallback((postId: string, postUpdate: Partial<Post>) => {
    const newPosts = store.posts.map(p => p.id === postId ? { ...p, ...postUpdate, id: p.id } : p);
    broadcast(newPosts);
    navigate(`/post/${postId}`);
  }, [navigate]);

  const deletePost = useCallback((postId: string) => {
    const newPosts = store.posts.filter(p => p.id !== postId);
    broadcast(newPosts);
  }, []);


  return { posts, loading, getPostById, addComment, deleteComment, createPost, updatePost, deletePost };
};