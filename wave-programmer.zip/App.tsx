
import React, { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import Header from './components/Header.tsx';
import Footer from './components/Footer.tsx';
import AdminRoute from './components/AdminRoute.tsx';

// Static imports to fix potential module resolution issues with lazy loading in this environment.
import HomePage from './pages/HomePage.tsx';
import PostPage from './pages/PostPage.tsx';
import AboutPage from './pages/AboutPage.tsx';
import NotFoundPage from './pages/NotFoundPage.tsx';
import LoginPage from './pages/LoginPage.tsx';
import SignUpPage from './pages/SignUpPage.tsx';
import AdminDashboard from './pages/AdminDashboard.tsx';
import EditPostPage from './pages/EditPostPage.tsx';


const App: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="flex flex-col min-h-screen">
      <Header onSearch={setSearchQuery} />
      <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Routes>
            <Route path="/" element={<HomePage searchQuery={searchQuery} />} />
            <Route path="/post/:postId" element={<PostPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/signup" element={<SignUpPage />} />
            
            {/* Admin Routes */}
            <Route path="/admin" element={<AdminRoute><AdminDashboard /></AdminRoute>} />
            <Route path="/admin/post/new" element={<AdminRoute><EditPostPage /></AdminRoute>} />
            <Route path="/admin/post/edit/:postId" element={<AdminRoute><EditPostPage /></AdminRoute>} />

            <Route path="*" element={<NotFoundPage />} />
          </Routes>
      </main>
      <Footer />
    </div>
  );
};

export default App;