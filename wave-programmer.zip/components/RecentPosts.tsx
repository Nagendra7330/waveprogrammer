
import React from 'react';
import { Link } from 'react-router-dom';
import { useBlogData } from '../hooks/useBlogData.ts';
import { format } from 'date-fns';
import { FiArrowRight } from 'react-icons/fi';

interface RecentPostsProps {
    currentPostId?: string;
}

const RecentPosts: React.FC<RecentPostsProps> = ({ currentPostId }) => {
  const { posts, loading } = useBlogData();
  
  const recentPosts = posts
    .filter(p => p.id !== currentPostId)
    .slice(0, 4);

  if (loading || recentPosts.length === 0) {
    return null;
  }

  return (
    <div className="p-6 bg-slate-800/50 rounded-lg">
      <h3 className="text-lg font-bold text-white mb-4 border-b border-slate-700 pb-2">Recent Posts</h3>
      <ul className="space-y-4">
        {recentPosts.map(post => (
          <li key={post.id}>
            <Link to={`/post/${post.id}`} className="group block">
              <p className="font-semibold text-slate-200 group-hover:text-purple-400 transition-colors">{post.title}</p>
              <p className="text-xs text-slate-400 mt-1">{format(new Date(post.date), 'MMM d, yyyy')}</p>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default RecentPosts;