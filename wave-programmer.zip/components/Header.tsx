
import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { FiActivity, FiLogOut, FiUser, FiEdit, FiShield, FiSearch, FiX, FiMenu } from 'react-icons/fi';
import { useAuth } from '../contexts/AuthContext.tsx';
import { motion, AnimatePresence } from 'framer-motion';

interface HeaderProps {
  onSearch: (query: string) => void;
}

const Header: React.FC<HeaderProps> = ({ onSearch }) => {
  const { user, logout } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
    onSearch(e.target.value);
  };

  const clearSearch = () => {
    setSearchQuery('');
    onSearch('');
  }

  const baseLinkClasses = "px-3 py-2 rounded-md text-sm font-medium transition-colors";
  const inactiveLinkClasses = "text-slate-300 hover:text-white";
  const activeLinkClasses = "text-purple-400 underline underline-offset-4 decoration-purple-400";
  
  const mobileLinkClasses = "block px-3 py-2 rounded-md text-base font-medium";

  return (
    <header className="bg-slate-900/70 backdrop-blur-md sticky top-0 z-50 border-b border-slate-800">
      <nav className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center gap-2 group">
              <FiActivity className="h-8 w-8 text-purple-400 group-hover:animate-pulse" />
              <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-400">
                Wave Programmer
              </span>
            </Link>
            <div className="hidden md:block ml-10">
              <div className="flex items-baseline space-x-4">
                <NavLink
                  to="/"
                  className={({ isActive }) => `${baseLinkClasses} ${isActive ? activeLinkClasses : inactiveLinkClasses}`}
                >
                  Home
                </NavLink>
                <NavLink
                  to="/about"
                  className={({ isActive }) => `${baseLinkClasses} ${isActive ? activeLinkClasses : inactiveLinkClasses}`}
                >
                  About
                </NavLink>
                 {user?.isAdmin && (
                   <NavLink
                    to="/admin"
                    className={({ isActive }) => `${baseLinkClasses} ${isActive ? activeLinkClasses : inactiveLinkClasses} flex items-center gap-1.5`}
                  >
                    <FiShield /> Admin
                  </NavLink>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative">
              <FiSearch className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-500" />
              <input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={handleSearchChange}
                className="bg-slate-800 border border-slate-700 rounded-full w-32 md:w-56 pl-10 pr-8 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all"
              />
              <AnimatePresence>
                {searchQuery && (
                  <motion.button
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0, opacity: 0 }}
                    onClick={clearSearch}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
                  >
                    <FiX />
                  </motion.button>
                )}
              </AnimatePresence>
            </div>
            {/* Desktop Auth */}
            <div className="hidden md:flex items-center gap-2">
                {user ? (
                  <>
                    <div className="flex items-center gap-2">
                       <img src={user.avatarUrl} alt={user.name} className="w-8 h-8 rounded-full border-2 border-slate-600" />
                    </div>
                    <button onClick={logout} className="flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium text-slate-300 hover:bg-slate-800 hover:text-white transition-colors">
                      <FiLogOut className="h-4 w-4" />
                      <span>Logout</span>
                    </button>
                  </>
                ) : (
                   <div className="flex items-baseline space-x-2">
                     <NavLink
                       to="/login"
                       className={`${baseLinkClasses} ${inactiveLinkClasses} flex items-center gap-1`}
                     >
                       <FiUser /> Login
                     </NavLink>
                      <NavLink
                       to="/signup"
                       className="flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium bg-purple-600 text-white hover:bg-purple-700 transition-colors"
                     >
                       <FiEdit /> Sign Up
                     </NavLink>
                   </div>
                )}
            </div>
            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-slate-400 hover:text-white hover:bg-slate-700 focus:outline-none"
              >
                <span className="sr-only">Open main menu</span>
                {isMobileMenuOpen ? <FiX className="block h-6 w-6" /> : <FiMenu className="block h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile menu, show/hide based on menu state. */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            className="md:hidden"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
          >
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 border-t border-slate-800">
               <NavLink to="/" onClick={() => setIsMobileMenuOpen(false)} className={({isActive}) => `${mobileLinkClasses} ${isActive ? 'bg-slate-800 text-white' : 'text-slate-300 hover:bg-slate-700 hover:text-white'}`}>Home</NavLink>
               <NavLink to="/about" onClick={() => setIsMobileMenuOpen(false)} className={({isActive}) => `${mobileLinkClasses} ${isActive ? 'bg-slate-800 text-white' : 'text-slate-300 hover:bg-slate-700 hover:text-white'}`}>About</NavLink>
               {user?.isAdmin && <NavLink to="/admin" onClick={() => setIsMobileMenuOpen(false)} className={({isActive}) => `${mobileLinkClasses} ${isActive ? 'bg-slate-800 text-white' : 'text-slate-300 hover:bg-slate-700 hover:text-white'}`}>Admin</NavLink>}
            
               <div className="pt-4 mt-4 border-t border-slate-700">
                {user ? (
                   <>
                     <div className="flex items-center px-3 mb-3">
                        <div className="flex-shrink-0">
                           <img className="h-10 w-10 rounded-full" src={user.avatarUrl} alt={user.name} />
                        </div>
                        <div className="ml-3">
                           <div className="text-base font-medium leading-none text-white">{user.name}</div>
                           <div className="text-sm font-medium leading-none text-slate-400">{user.email}</div>
                        </div>
                     </div>
                     <button onClick={() => { logout(); setIsMobileMenuOpen(false); }} className={`w-full text-left ${mobileLinkClasses} text-slate-300 hover:bg-slate-700 hover:text-white`}>
                        <FiLogOut className="inline-block mr-2"/> Logout
                     </button>
                   </>
                ) : (
                  <div className="space-y-1">
                     <NavLink to="/login" onClick={() => setIsMobileMenuOpen(false)} className={({isActive}) => `${mobileLinkClasses} ${isActive ? 'bg-slate-800 text-white' : 'text-slate-300 hover:bg-slate-700 hover:text-white'}`}><FiUser className="inline-block mr-2"/> Login</NavLink>
                     <NavLink to="/signup" onClick={() => setIsMobileMenuOpen(false)} className={({isActive}) => `${mobileLinkClasses} ${isActive ? 'bg-slate-800 text-white' : 'text-slate-300 hover:bg-slate-700 hover:text-white'}`}><FiEdit className="inline-block mr-2"/> Sign Up</NavLink>
                  </div>
                )}
               </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;
