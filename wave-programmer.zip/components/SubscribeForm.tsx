import React, { useState } from 'react';
import { FiCheckCircle } from 'react-icons/fi';

const SubscribeForm: React.FC = () => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if(email) {
        // In a real app, you would handle the API call here.
        setSubmitted(true);
    }
  };

  if (submitted) {
    return (
      <div className="flex items-center gap-3 p-3 bg-green-900/50 text-green-300 rounded-lg">
        <FiCheckCircle className="h-6 w-6" />
        <p className="font-semibold">Thanks for subscribing! We'll be in touch.</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2">
      <label htmlFor="email-address" className="sr-only">
        Email address
      </label>
      <input
        type="email"
        name="email-address"
        id="email-address"
        autoComplete="email"
        required
        className="flex-auto w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-md shadow-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-purple-500 focus:border-purple-500 sm:text-sm text-white"
        placeholder="Enter your email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <button
        type="submit"
        className="flex-shrink-0 inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-purple-500 transition-colors"
      >
        Subscribe
      </button>
    </form>
  );
};

export default SubscribeForm;