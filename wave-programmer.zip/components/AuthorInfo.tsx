


import React from 'react';
import { format } from 'date-fns';
import type { Author } from '../types.ts';

interface AuthorInfoProps {
  author: Author;
  date: string;
}

const AuthorInfo: React.FC<AuthorInfoProps> = ({ author, date }) => {
  return (
    <div className="flex items-center gap-3">
      <img className="w-10 h-10 rounded-full object-cover" src={author.avatarUrl} alt={author.name} />
      <div>
        <p className="text-sm font-semibold text-slate-200">{author.name}</p>
        <p className="text-xs text-slate-400">{format(new Date(date), 'MMMM d, yyyy')}</p>
      </div>
    </div>
  );
};

export default React.memo(AuthorInfo);