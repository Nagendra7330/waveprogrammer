
import React from 'react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import type { Post } from '../types.ts';
import AuthorInfo from './AuthorInfo.tsx';

interface PostCardProps {
  post: Post;
}

const PostCard: React.FC<PostCardProps> = ({ post }) => {
  return (
    <Link to={`/post/${post.id}`} className="block group bg-slate-800 rounded-lg overflow-hidden shadow-lg hover:shadow-purple-500/20 transition-all duration-300 hover:-translate-y-1">
      <div className="relative">
        <img className="w-full h-48 object-cover" src={post.imageUrl} alt={post.title} />
        <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors"></div>
      </div>
      <div className="p-6">
        <div className="flex flex-wrap gap-2 mb-2">
          {post.tags.map(tag => (
            <span key={tag} className="inline-block bg-purple-900/50 text-purple-300 text-xs font-semibold px-2.5 py-1 rounded-full">
              {tag}
            </span>
          ))}
        </div>
        <h3 className="text-xl font-bold text-slate-100 group-hover:text-purple-400 transition-colors">{post.title}</h3>
        <p className="mt-2 text-slate-400 text-sm leading-relaxed">{post.excerpt}</p>
        <div className="mt-4">
          <AuthorInfo author={post.author} date={post.date} />
        </div>
      </div>
    </Link>
  );
};

export default React.memo(PostCard);