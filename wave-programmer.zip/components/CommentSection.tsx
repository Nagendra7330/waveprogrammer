
import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext.tsx';
import type { Comment as CommentType, User } from '../types.ts';
import { formatDistanceToNow } from 'date-fns';
import { FiMessageSquare, FiTrash, FiSend } from 'react-icons/fi';
import { Link } from 'react-router-dom';

interface CommentSectionProps {
  postId: string;
  comments: CommentType[];
  addComment: (postId: string, comment: { user: User; content: string }) => void;
  deleteComment: (postId: string, commentId: string) => void;
}

const CommentSection: React.FC<CommentSectionProps> = ({ postId, comments, addComment, deleteComment }) => {
  const { user } = useAuth();
  const [newComment, setNewComment] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newComment.trim() && user) {
      addComment(postId, { user, content: newComment.trim() });
      setNewComment('');
    }
  };

  return (
    <div className="bg-slate-800/50 rounded-lg p-6">
      <h2 className="flex items-center gap-3 text-2xl font-bold text-white mb-6">
        <FiMessageSquare className="text-purple-400" />
        <span>Comments ({comments.length})</span>
      </h2>
      
      {/* Comment Form */}
      <div className="mb-8">
        {user ? (
          <form onSubmit={handleSubmit} className="flex items-start gap-4">
            <img src={user.avatarUrl} alt={user.name} className="w-10 h-10 rounded-full" />
            <div className="flex-1">
              <textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Add to the discussion..."
                className="block w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-md shadow-sm placeholder-slate-500 focus:outline-none focus:ring-purple-500 focus:border-purple-500 sm:text-sm transition-colors"
                rows={3}
              />
              <button type="submit" disabled={!newComment.trim()} className="mt-2 inline-flex items-center gap-2 px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-purple-600 hover:bg-purple-700 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors">
                <FiSend />
                Post Comment
              </button>
            </div>
          </form>
        ) : (
          <div className="text-center text-slate-400 border border-dashed border-slate-700 rounded-lg p-6">
            <p>
              <Link to="/login" className="font-medium text-purple-400 hover:underline">Log in</Link> or{' '}
              <Link to="/signup" className="font-medium text-purple-400 hover:underline">sign up</Link> to join the discussion.
            </p>
          </div>
        )}
      </div>

      {/* Comments List */}
      <div className="space-y-6">
        {comments.length > 0 ? (
          comments
            .slice()
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
            .map(comment => (
            <div key={comment.id} className="flex items-start gap-4">
              <img src={comment.user.avatarUrl} alt={comment.user.name} className="w-10 h-10 rounded-full" />
              <div className="flex-1 bg-slate-800 p-4 rounded-lg">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-white">{comment.user.name}</p>
                    {comment.user.isAdmin && <span className="text-xs font-bold text-purple-400 bg-purple-900/50 px-2 py-0.5 rounded-full">Admin</span>}
                  </div>
                  {user?.isAdmin && (
                    <button onClick={() => deleteComment(postId, comment.id)} className="text-slate-500 hover:text-red-400 transition-colors">
                      <FiTrash className="h-4 w-4" />
                    </button>
                  )}
                </div>
                <p className="text-sm text-slate-400 mb-2">{formatDistanceToNow(new Date(comment.date), { addSuffix: true })}</p>
                <p className="text-slate-300">{comment.content}</p>
              </div>
            </div>
          ))
        ) : (
          <p className="text-slate-500 text-center py-4">Be the first to comment!</p>
        )}
      </div>
    </div>
  );
};

export default CommentSection;