import React, { useEffect } from 'react';

interface SEOProps {
  title: string;
  description: string;
  path?: string;
  imageUrl?: string;
  author?: string;
  publishedDate?: string;
  tags?: string[];
}

const SEO: React.FC<SEOProps> = ({
  title,
  description,
  path = '/',
  imageUrl,
  author,
  publishedDate,
  tags
}) => {
  useEffect(() => {
    document.title = title;

    const setMeta = (name: string, content: string) => {
      let element = document.querySelector(`meta[name='${name}']`) as HTMLMetaElement;
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute('name', name);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    const setProperty = (property: string, content: string) => {
        let element = document.querySelector(`meta[property='${property}']`) as HTMLMetaElement;
        if (!element) {
            element = document.createElement('meta');
            element.setAttribute('property', property);
            document.head.appendChild(element);
        }
        element.setAttribute('content', content);
    }
    
    // Fallback image if not provided
    const effectiveImageUrl = imageUrl || 'https://picsum.photos/seed/wave/1200/630';
    const siteUrl = window.location.origin + window.location.pathname;
    const fullUrl = siteUrl.replace(/#\/.*$/, '') + `#${path}`;

    setMeta('description', description);
    
    // Open Graph
    setProperty('og:title', title);
    setProperty('og:description', description);
    setProperty('og:type', author ? 'article' : 'website');
    setProperty('og:url', fullUrl);
    setProperty('og:image', effectiveImageUrl);
    setProperty('og:site_name', 'Wave Programmer');
    
    // Twitter Card
    setMeta('twitter:card', 'summary_large_image');
    setMeta('twitter:title', title);
    setMeta('twitter:description', description);
    setMeta('twitter:image', effectiveImageUrl);

    // JSON-LD Structured Data
    const scriptId = 'json-ld-data';
    let script = document.getElementById(scriptId) as HTMLScriptElement;
    if(!script){
        script = document.createElement('script');
        script.id = scriptId;
        script.type = 'application/ld+json';
        document.head.appendChild(script);
    }

    const schema = author ? {
      '@context': 'https://schema.org',
      '@type': 'BlogPosting',
      mainEntityOfPage: {
        '@type': 'WebPage',
        '@id': fullUrl,
      },
      headline: title,
      description: description,
      image: effectiveImageUrl,
      author: {
        '@type': 'Person',
        name: author,
      },
      publisher: {
        '@type': 'Organization',
        name: 'Wave Programmer',
        logo: {
            '@type': 'ImageObject',
            url: 'https://your-domain.com/logo.png', // Placeholder logo
        },
      },
      datePublished: publishedDate,
      keywords: tags?.join(', '),
    } : {
        '@context': 'https://schema.org',
        '@type': 'WebSite',
        url: fullUrl,
        name: 'Wave Programmer',
        description: description,
    };
    
    script.textContent = JSON.stringify(schema);

  }, [title, description, path, imageUrl, author, publishedDate, tags]);

  return null;
};

export default SEO;