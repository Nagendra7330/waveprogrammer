
import React from 'react';
import SubscribeForm from './SubscribeForm.tsx';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 border-t border-slate-800 mt-16">
      <div className="container mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="max-w-md">
             <h3 className="text-2xl font-bold text-white mb-2 bg-clip-text text-transparent bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-400">Stay Ahead of the Wave</h3>
             <p className="text-slate-400 mb-6">Subscribe to our newsletter for the latest articles, tutorials, and tech news, delivered straight to your inbox.</p>
             <SubscribeForm />
          </div>
          <div className="text-center lg:text-right text-slate-400">
            <p>&copy; {new Date().getFullYear()} Wave Programmer. A Template Project.</p>
            <p className="text-sm mt-1">Built with React, Tailwind CSS, and Gemini API.</p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;