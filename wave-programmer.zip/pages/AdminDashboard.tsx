
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useBlogData } from '../hooks/useBlogData.ts';
import { useAuth } from '../contexts/AuthContext.tsx';
import { format } from 'date-fns';
import { FiPlus, FiEdit, FiTrash2, FiBarChart2, FiMessageSquare } from 'react-icons/fi';
import SEO from '../components/SEO.tsx';

const AdminDashboard: React.FC = () => {
  const { posts, loading, deletePost } = useBlogData();
  const { user } = useAuth();
  const navigate = useNavigate();

  const totalComments = posts.reduce((acc, post) => acc + post.comments.length, 0);

  const handleEdit = (postId: string) => {
    navigate(`/admin/post/edit/${postId}`);
  };

  const handleDelete = (postId: string) => {
    if (window.confirm('Are you sure you want to delete this post? This action cannot be undone.')) {
      deletePost(postId);
    }
  };

  return (
    <>
    <SEO title="Admin Dashboard | Wave Programmer" description="Admin dashboard for Wave Programmer." />
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-4xl font-extrabold text-white">Admin Dashboard</h1>
        <Link 
          to="/admin/post/new"
          className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white font-semibold rounded-lg hover:bg-purple-700 transition-colors"
        >
          <FiPlus /> New Post
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-800 p-6 rounded-lg flex items-center gap-4">
            <FiBarChart2 className="h-8 w-8 text-purple-400" />
            <div>
                <p className="text-slate-400 text-sm">Total Posts</p>
                <p className="text-2xl font-bold text-white">{posts.length}</p>
            </div>
        </div>
        <div className="bg-slate-800 p-6 rounded-lg flex items-center gap-4">
            <FiMessageSquare className="h-8 w-8 text-purple-400" />
            <div>
                <p className="text-slate-400 text-sm">Total Comments</p>
                <p className="text-2xl font-bold text-white">{totalComments}</p>
            </div>
        </div>
        <div className="bg-slate-800 p-6 rounded-lg flex items-center gap-4">
             <img src={user?.avatarUrl} alt="Admin" className="w-12 h-12 rounded-full" />
            <div>
                <p className="text-slate-400 text-sm">Logged in as</p>
                <p className="text-xl font-bold text-white">{user?.name}</p>
            </div>
        </div>
      </div>
      
      {/* Posts Table */}
      <div className="bg-slate-800/50 rounded-lg overflow-hidden">
        <div className="p-4">
            <h2 className="text-2xl font-bold text-white">Manage Posts</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-700">
            <thead className="bg-slate-800">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">Title</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">Date</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">Comments</th>
                <th scope="col" className="relative px-6 py-3">
                  <span className="sr-only">Actions</span>
                </th>
              </tr>
            </thead>
            <tbody className="bg-slate-800/50 divide-y divide-slate-700">
              {posts.map((post) => (
                <tr key={post.id} className="hover:bg-slate-800 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <Link to={`/post/${post.id}`} className="text-sm font-medium text-purple-400 hover:underline">{post.title}</Link>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-400">{format(new Date(post.date), 'MMM d, yyyy')}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-400">{post.comments.length}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-4">
                    <button onClick={() => handleEdit(post.id)} className="text-slate-300 hover:text-white transition-colors"><FiEdit /></button>
                    <button onClick={() => handleDelete(post.id)} className="text-red-500 hover:text-red-400 transition-colors"><FiTrash2 /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
    </>
  );
};

export default AdminDashboard;
