
import React from 'react';
import SEO from '../components/SEO.tsx';

const AboutPage: React.FC = () => {
  return (
    <>
      <SEO 
        title="About | Wave Programmer"
        description="Learn about Wave Programmer, a project showcasing modern web development with React, TypeScript, Tailwind CSS, and the Gemini API for AI-powered features."
      />
      <div className="max-w-4xl mx-auto py-12">
        <h1 className="text-4xl font-extrabold text-white mb-6">About Wave Programmer</h1>
        <div className="prose prose-lg prose-invert max-w-none prose-p:text-slate-300 prose-a:text-purple-400">
          <p>
            Welcome to Wave Programmer, a modern demonstration of a web application built with the latest frontend technologies. This project serves as a template for developers looking to create a stylish, functional, and AI-enhanced blog.
          </p>
          <p>
            This entire application was generated to showcase a world-class implementation of:
          </p>
          <ul>
            <li><strong>React 19 & TypeScript:</strong> For a robust and type-safe component-based architecture.</li>
            <li><strong>Tailwind CSS:</strong> For rapid, utility-first styling that results in a sleek and responsive design.</li>
            <li><strong>Admin Dashboard:</strong> Full Create, Read, Update, Delete (CRUD) functionality for posts.</li>
            <li><strong>SEO Optimization:</strong> Dynamic meta tags and JSON-LD structured data for top search engine rankings.</li>
            <li><strong>Gemini API:</strong> To power intelligent features, such as the AI-driven post summarization you can find on article pages.</li>
          </ul>
          <p>
            The goal of this template is to provide a solid foundation that is easy to customize and deploy. You can clone the repository, replace the mock data with your own content source (like a headless CMS), and deploy it to a platform like Vercel in minutes.
          </p>
          <p>
            Feel free to explore the code, experiment with the features, and adapt it for your own projects!
          </p>
        </div>
      </div>
    </>
  );
};

export default AboutPage;