
import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useBlogData } from '../hooks/useBlogData.ts';
import { useAuth } from '../contexts/AuthContext.tsx';
import { summarizeContent, isApiKeyAvailable } from '../services/geminiService.ts';
import type { Post } from '../types.ts';
import AuthorInfo from '../components/AuthorInfo.tsx';
import Spinner from '../components/Spinner.tsx';
import NotFoundPage from './NotFoundPage.tsx';
import AdPlaceholder from '../components/AdPlaceholder.tsx';
import CommentSection from '../components/CommentSection.tsx';
import RecentPosts from '../components/RecentPosts.tsx';
import SEO from '../components/SEO.tsx';
import { FiActivity, FiTag, FiEdit, FiTrash2 } from 'react-icons/fi';

const PostPage: React.FC = () => {
  const { postId } = useParams<{ postId: string }>();
  const { getPostById, loading: blogLoading, addComment, deleteComment, deletePost } = useBlogData();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [post, setPost] = useState<Post | undefined>(undefined);
  const [summary, setSummary] = useState<string>('');
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [summaryError, setSummaryError] = useState<string>('');

  useEffect(() => {
    if (!blogLoading && postId) {
      const foundPost = getPostById(postId);
      setPost(foundPost);
      // Reset summary when post changes
      setSummary('');
      setSummaryError('');
    }
  }, [postId, getPostById, blogLoading]);
  
  const handleSummarize = async () => {
    if (!post) return;
    setIsSummarizing(true);
    setSummaryError('');
    setSummary('');
    try {
      const result = await summarizeContent(post.content);
      setSummary(result);
    } catch (error) {
      if(error instanceof Error) {
        setSummaryError(error.message);
      } else {
        setSummaryError('An unknown error occurred.');
      }
    } finally {
      setIsSummarizing(false);
    }
  };

  if (blogLoading) {
    return (
      <div className="flex justify-center items-center h-96">
        <Spinner />
      </div>
    );
  }

  if (!post) {
    return <NotFoundPage />;
  }
  
  const handleEdit = () => {
      navigate(`/admin/post/edit/${post.id}`);
  }
  
  const handleDelete = () => {
      // Confirmation and navigation logic now lives in the component
      if (window.confirm('Are you sure you want to delete this post? This action cannot be undone.')) {
          deletePost(post.id);
          navigate('/');
      }
  }

  return (
    <>
    <SEO
      title={`${post.title} | Wave Programmer`}
      description={post.excerpt}
      imageUrl={post.imageUrl}
      author={post.author.name}
      publishedDate={post.date}
      tags={post.tags}
      path={`/post/${post.id}`}
    />
    <div className="max-w-7xl mx-auto grid lg:grid-cols-12 gap-8 lg:gap-12">
      <div className="lg:col-span-8">
        <article>
          <header className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <Link to="/" className="text-purple-400 hover:underline">&larr; Back to all posts</Link>
              {user?.isAdmin && (
                <div className="flex gap-2">
                   <button onClick={handleEdit} className="flex items-center gap-2 px-3 py-1.5 rounded-md text-sm font-medium text-slate-300 bg-slate-700 hover:bg-slate-600 transition-colors">
                       <FiEdit className="h-4 w-4" />
                       Edit
                   </button>
                   <button onClick={handleDelete} className="flex items-center gap-2 px-3 py-1.5 rounded-md text-sm font-medium text-white bg-red-600 hover:bg-red-700 transition-colors">
                       <FiTrash2 className="h-4 w-4" />
                       Delete
                   </button>
                </div>
              )}
            </div>
            <h1 className="text-4xl md:text-5xl font-extrabold text-white leading-tight mb-4">{post.title}</h1>
            <p className="text-lg text-slate-400">{post.excerpt}</p>
          </header>

          <div className="mb-8">
            <button
              onClick={handleSummarize}
              disabled={isSummarizing || !isApiKeyAvailable}
              className="inline-flex items-center gap-2 px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-purple-600 hover:bg-purple-700 disabled:bg-slate-600 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-purple-500 transition-colors"
            >
              {isSummarizing ? (
                <>
                  <Spinner />
                  Summarizing...
                </>
              ) : (
                 <>
                  <FiActivity className="h-5 w-5" />
                  Summarize with AI
                 </>
              )}
            </button>
             {!isApiKeyAvailable && <p className="text-xs text-amber-400 mt-2">AI features disabled. API_KEY is not set.</p>}
          </div>
          
          {summaryError && <div className="my-6 p-4 bg-red-900/50 border border-red-700 text-red-300 rounded-lg">{summaryError}</div>}
          
          {summary && (
            <div className="my-8 p-6 bg-slate-800/50 border-l-4 border-purple-400 rounded-r-lg">
               <h2 className="flex items-center gap-2 text-xl font-bold text-slate-100 mb-3">
                 <FiActivity className="h-6 w-6 text-purple-400"/>
                 AI Summary
               </h2>
              <div className="prose prose-invert prose-sm max-w-none prose-p:text-slate-300 prose-li:text-slate-300" dangerouslySetInnerHTML={{ __html: summary.replace(/\*/g, '').replace(/\n/g, '<br />') }} />
            </div>
          )}

          <div className="mb-8 rounded-lg overflow-hidden shadow-lg">
            <img className="w-full h-auto object-cover" src={post.imageUrl} alt={post.title} />
          </div>
          
          <div 
            className="prose prose-lg prose-invert max-w-none 
                       prose-p:text-slate-300 prose-headings:text-white 
                       prose-strong:text-slate-100 prose-a:text-purple-400 
                       prose-blockquote:border-purple-400 prose-blockquote:text-slate-400
                       prose-code:bg-slate-800 prose-code:text-amber-300 prose-code:p-1 prose-code:rounded-md
                       prose-pre:bg-slate-800 prose-pre:p-4 prose-pre:rounded-lg"
          >
            <div style={{ whiteSpace: 'pre-wrap' }}>{post.content}</div>
          </div>
          
          <div className="mt-16">
            <CommentSection 
              postId={post.id}
              comments={post.comments}
              addComment={addComment}
              deleteComment={deleteComment}
            />
          </div>
        </article>
      </div>

      <aside className="lg:col-span-4 space-y-8 lg:sticky lg:top-24 self-start">
        <div className="p-6 bg-slate-800/50 rounded-lg">
          <h3 className="text-lg font-bold text-white mb-4 border-b border-slate-700 pb-2">About the Author</h3>
          <AuthorInfo author={post.author} date={post.date} />
        </div>
        <div className="p-6 bg-slate-800/50 rounded-lg">
          <h3 className="text-lg font-bold text-white mb-4 border-b border-slate-700 pb-2">Tags</h3>
          <div className="flex flex-wrap gap-2">
            {post.tags.map(tag => (
              <span key={tag} className="inline-flex items-center gap-1.5 bg-purple-900/50 text-purple-300 text-xs font-semibold px-2.5 py-1 rounded-full">
                <FiTag className="h-3 w-3" />
                {tag}
              </span>
            ))}
          </div>
        </div>
        <RecentPosts currentPostId={post.id} />
        <AdPlaceholder />
      </aside>
    </div>
    </>
  );
};

export default PostPage;
