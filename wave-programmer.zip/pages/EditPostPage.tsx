
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useBlogData } from '../hooks/useBlogData.ts';
import { useAuth } from '../contexts/AuthContext.tsx';
import type { Post } from '../types.ts';
import Spinner from '../components/Spinner.tsx';
import SEO from '../components/SEO.tsx';

const EditPostPage: React.FC = () => {
  const { postId } = useParams<{ postId?: string }>();
  const navigate = useNavigate();
  const { getPostById, createPost, updatePost, loading } = useBlogData();
  const { user } = useAuth();
  
  const [postData, setPostData] = useState({
    title: '',
    excerpt: '',
    content: '',
    imageUrl: '',
    tags: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const isNewPost = !postId;

  useEffect(() => {
    if (!isNewPost && !loading) {
      const post = getPostById(postId);
      if (post) {
        setPostData({
          title: post.title,
          excerpt: post.excerpt,
          content: post.content,
          imageUrl: post.imageUrl,
          tags: post.tags.join(', '),
        });
      } else {
        navigate('/404');
      }
    }
  }, [postId, isNewPost, getPostById, loading, navigate]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setPostData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit for localStorage safety
        alert('File is too large! Please upload an image under 5MB.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setPostData(prev => ({ ...prev, imageUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    setIsSubmitting(true);
    const postToSubmit = {
      ...postData,
      tags: postData.tags.split(',').map(tag => tag.trim()).filter(Boolean),
    };

    setTimeout(() => { // Simulate API delay
        if (isNewPost) {
            createPost(postToSubmit, user);
        } else if(postId) {
            updatePost(postId, postToSubmit);
        }
        setIsSubmitting(false);
    }, 1000);
  };

  if (loading && !isNewPost) {
    return <div className="flex justify-center items-center h-96"><Spinner /></div>;
  }

  return (
    <>
    <SEO 
      title={`${isNewPost ? 'Create New Post' : 'Edit Post'} | Wave Programmer`} 
      description={`Administrative page to ${isNewPost ? 'create a new' : 'edit an existing'} blog post.`} 
    />
    <div className="max-w-4xl mx-auto">
      <h1 className="text-4xl font-extrabold text-white mb-8">{isNewPost ? 'Create New Post' : 'Edit Post'}</h1>
      <form onSubmit={handleSubmit} className="space-y-6 bg-slate-800/50 p-8 rounded-lg">
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-slate-300 mb-1">Title</label>
          <input type="text" name="title" id="title" value={postData.title} onChange={handleChange} required className="w-full bg-slate-900 border border-slate-700 rounded-md p-2 focus:ring-purple-500 focus:border-purple-500"/>
        </div>
        <div>
          <label htmlFor="excerpt" className="block text-sm font-medium text-slate-300 mb-1">Excerpt</label>
          <textarea name="excerpt" id="excerpt" value={postData.excerpt} onChange={handleChange} required rows={3} className="w-full bg-slate-900 border border-slate-700 rounded-md p-2 focus:ring-purple-500 focus:border-purple-500"/>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">Post Image</label>
          
          {postData.imageUrl && (
            <div className="mb-4">
              <img src={postData.imageUrl} alt="Post preview" className="w-full max-w-md h-auto object-cover rounded-lg shadow-md bg-slate-900" />
            </div>
          )}

          <div className="flex items-center justify-center w-full">
            <label htmlFor="image-upload" className="flex flex-col items-center justify-center w-full h-32 border-2 border-slate-700 border-dashed rounded-lg cursor-pointer bg-slate-900 hover:bg-slate-800 transition-colors">
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <svg className="w-8 h-8 mb-4 text-slate-500" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 16">
                        <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2"/>
                    </svg>
                    <p className="mb-2 text-sm text-slate-400"><span className="font-semibold">Click to upload</span> or drag and drop</p>
                    <p className="text-xs text-slate-500">PNG, JPG, GIF (Max 5MB)</p>
                </div>
                <input id="image-upload" type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
            </label>
          </div>
          
          <div className="my-4 relative flex items-center">
            <div className="flex-grow border-t border-slate-700"></div>
            <span className="flex-shrink mx-4 text-slate-500 text-sm">OR</span>
            <div className="flex-grow border-t border-slate-700"></div>
          </div>

          <label htmlFor="imageUrl" className="block text-sm font-medium text-slate-300 mb-1">Paste Image URL</label>
          <input type="url" name="imageUrl" id="imageUrl" value={postData.imageUrl} onChange={handleChange} required placeholder="https://example.com/image.jpg" className="w-full bg-slate-900 border-slate-700 rounded-md p-2 focus:ring-purple-500 focus:border-purple-500"/>
        </div>

        <div>
          <label htmlFor="content" className="block text-sm font-medium text-slate-300 mb-1">Content (Markdown supported)</label>
          <textarea name="content" id="content" value={postData.content} onChange={handleChange} required rows={15} className="w-full bg-slate-900 border-slate-700 rounded-md p-2 focus:ring-purple-500 focus:border-purple-500 font-mono text-sm"/>
        </div>
        <div>
          <label htmlFor="tags" className="block text-sm font-medium text-slate-300 mb-1">Tags (comma-separated)</label>
          <input type="text" name="tags" id="tags" value={postData.tags} onChange={handleChange} required className="w-full bg-slate-900 border-slate-700 rounded-md p-2 focus:ring-purple-500 focus:border-purple-500"/>
        </div>
        <div className="flex justify-end gap-4">
            <button type="button" onClick={() => navigate('/admin')} className="px-4 py-2 bg-slate-600 text-white font-semibold rounded-lg hover:bg-slate-700 transition-colors disabled:opacity-50">
                Cancel
            </button>
            <button type="submit" disabled={isSubmitting} className="px-4 py-2 bg-purple-600 text-white font-semibold rounded-lg hover:bg-purple-700 transition-colors disabled:opacity-50 disabled:cursor-wait flex items-center gap-2">
                {isSubmitting && <Spinner />}
                {isNewPost ? 'Publish Post' : 'Update Post'}
            </button>
        </div>
      </form>
    </div>
    </>
  );
};

export default EditPostPage;
