
import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useBlogData } from '../hooks/useBlogData.ts';
import PostCard from '../components/PostCard.tsx';
import AuthorInfo from '../components/AuthorInfo.tsx';
import Spinner from '../components/Spinner.tsx';
import AdPlaceholder from '../components/AdPlaceholder.tsx';
import SEO from '../components/SEO.tsx';
import { motion } from 'framer-motion';

interface HomePageProps {
  searchQuery: string;
}

const HomePage: React.FC<HomePageProps> = ({ searchQuery }) => {
  const { posts, loading } = useBlogData();

  const filteredPosts = useMemo(() => {
    if (!searchQuery) return posts;
    return posts.filter(post =>
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
    );
  }, [posts, searchQuery]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-96">
        <Spinner />
      </div>
    );
  }

  const [featuredPost, ...otherPosts] = filteredPosts;
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };


  return (
    <div className="space-y-16">
      <SEO 
        title="Home | Wave Programmer"
        description="The official homepage for Wave Programmer, a modern tech blog. Find the latest articles on React, AI, Vercel, and web development."
      />
      
      {searchQuery && (
         <div className="pb-4 mb-8 border-b border-slate-700">
           <h1 className="text-2xl font-bold">Search results for: <span className="text-purple-400">"{searchQuery}"</span></h1>
           <p className="text-slate-400 mt-1">{filteredPosts.length} post(s) found.</p>
         </div>
      )}

      {/* Featured Post */}
      {featuredPost && !searchQuery && (
        <motion.section
           variants={itemVariants}
           initial="hidden"
           animate="visible"
        >
          <Link to={`/post/${featuredPost.id}`} className="block group">
            <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
              <div className="overflow-hidden rounded-lg">
                <motion.img 
                  src={featuredPost.imageUrl} 
                  alt={featuredPost.title}
                  className="w-full h-full object-cover aspect-video"
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.3 }}
                />
              </div>
              <div className="space-y-4">
                <span className="text-purple-400 font-semibold">Featured Article</span>
                <h1 className="text-4xl lg:text-5xl font-extrabold text-slate-100 group-hover:text-white transition-colors">{featuredPost.title}</h1>
                <p className="text-lg text-slate-400">{featuredPost.excerpt}</p>
                <div className="pt-2">
                  <AuthorInfo author={featuredPost.author} date={featuredPost.date} />
                </div>
              </div>
            </div>
          </Link>
        </motion.section>
      )}

      {/* All Posts Grid */}
      <section>
        <h2 className="text-3xl font-bold mb-8 border-b-2 border-purple-500 pb-2 inline-block">
            {searchQuery ? "Search Results" : "Recent Posts"}
        </h2>
        {filteredPosts.length > 0 ? (
          <motion.div 
            className="grid gap-8 md:grid-cols-2 lg:grid-cols-3"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
           >
            {filteredPosts.map((post, index) => (
                <motion.div key={post.id} variants={itemVariants}>
                    {(index === 2) && <div className="mb-8 md:hidden lg:block"><AdPlaceholder /></div>}
                    <PostCard post={post} />
                </motion.div>
            ))}
          </motion.div>
        ) : (
          <div className="text-center py-16 bg-slate-800/50 rounded-lg">
             <h3 className="text-2xl font-bold">No Posts Found</h3>
             <p className="text-slate-400 mt-2">Try adjusting your search query or check back later!</p>
          </div>
        )}
      </section>
    </div>
  );
};

export default HomePage;